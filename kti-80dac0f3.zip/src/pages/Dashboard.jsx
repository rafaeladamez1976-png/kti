import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { Bell, AlertTriangle, Map, Calendar, ChevronRight } from 'lucide-react';
import StatsCard from '@/components/ui/StatsCard';
import PageHeader from '@/components/ui/PageHeader';
import MapView from '@/components/map/MapView';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function Dashboard({ user }) {
  const navigate = useNavigate();

  const { data: alertas = [], isLoading: loadingAlertas } = useQuery({
    queryKey: ['alertas'],
    queryFn: () => base44.entities.Alerta.list('-created_date', 100)
  });

  const { data: territorios = [], isLoading: loadingTerritorios } = useQuery({
    queryKey: ['territorios'],
    queryFn: () => base44.entities.Territorio.list('-created_date', 100)
  });

  const { data: hallazgos = [], isLoading: loadingHallazgos } = useQuery({
    queryKey: ['hallazgos'],
    queryFn: () => base44.entities.Hallazgo.list('-created_date', 100)
  });

  const { data: analisis = [], isLoading: loadingAnalisis } = useQuery({
    queryKey: ['analisis'],
    queryFn: () => base44.entities.Analisis.list('-created_date', 10)
  });

  const alertasActivas = alertas.filter(a => a.estado === 'activa');
  const riesgosAltos = hallazgos.filter(h => h.nivel_riesgo === 'alto' && !h.revisado);
  const territoriosActivos = territorios.filter(t => t.activo);
  
  const ultimoAnalisis = analisis.find(a => a.estado === 'completado');

  const handleTerritorioClick = (territorio) => {
    navigate(createPageUrl('Territorios') + `?id=${territorio.id}`);
  };

  const handleHallazgoClick = (hallazgo) => {
    navigate(createPageUrl('HallazgoDetalle') + `?id=${hallazgo.id}`);
  };

  const isLoading = loadingAlertas || loadingTerritorios || loadingHallazgos || loadingAnalisis;

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Centro de Control"
        description={`Bienvenido, ${user?.full_name || 'Usuario'}`}
      />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Alertas detectadas"
          value={isLoading ? '-' : alertasActivas.length}
          icon={Bell}
          color="red"
          subtitle="Alertas activas"
        />
        <StatsCard
          title="Riesgos altos activos"
          value={isLoading ? '-' : riesgosAltos.length}
          icon={AlertTriangle}
          color="amber"
          subtitle="Sin revisar"
        />
        <StatsCard
          title="Territorios activos"
          value={isLoading ? '-' : territoriosActivos.length}
          icon={Map}
          color="emerald"
          subtitle={`de ${territorios.length} totales`}
        />
        <StatsCard
          title="Último análisis"
          value={ultimoAnalisis ? format(new Date(ultimoAnalisis.created_date), 'dd MMM', { locale: es }) : 'Sin análisis'}
          icon={Calendar}
          color="blue"
          subtitle={ultimoAnalisis?.territorio_nombre || ''}
        />
      </div>

      {/* Main Map */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Mapa de Territorios y Hallazgos</CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate(createPageUrl('Territorios'))}
            >
              Ver todos <ChevronRight size={16} className="ml-1" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <MapView
            territorios={territorios}
            hallazgos={hallazgos}
            height="450px"
            onTerritorioClick={handleTerritorioClick}
            onHallazgoClick={handleHallazgoClick}
          />
        </CardContent>
      </Card>

      {/* Recent Alerts & Findings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Alertas Recientes</CardTitle>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate(createPageUrl('Alertas'))}
              >
                Ver todas
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {alertasActivas.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No hay alertas activas</p>
              </div>
            ) : (
              <div className="space-y-3">
                {alertasActivas.slice(0, 5).map((alerta) => (
                  <div 
                    key={alerta.id}
                    className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors"
                    onClick={() => navigate(createPageUrl('Alertas') + `?id=${alerta.id}`)}
                  >
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      alerta.nivel === 'alto' ? 'bg-red-500' :
                      alerta.nivel === 'medio' ? 'bg-amber-500' : 'bg-green-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{alerta.titulo}</p>
                      <p className="text-xs text-slate-500 truncate">{alerta.territorio_nombre || 'Sin territorio'}</p>
                    </div>
                    <Badge variant="outline" className="text-xs capitalize">
                      {alerta.nivel}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Findings */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Hallazgos Recientes</CardTitle>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate(createPageUrl('Hallazgos'))}
              >
                Ver todos
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {hallazgos.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No hay hallazgos registrados</p>
              </div>
            ) : (
              <div className="space-y-3">
                {hallazgos.slice(0, 5).map((hallazgo) => (
                  <div 
                    key={hallazgo.id}
                    className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors"
                    onClick={() => navigate(createPageUrl('HallazgoDetalle') + `?id=${hallazgo.id}`)}
                  >
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      hallazgo.nivel_riesgo === 'alto' ? 'bg-red-500' :
                      hallazgo.nivel_riesgo === 'medio' ? 'bg-amber-500' : 'bg-green-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{hallazgo.nombre}</p>
                      <p className="text-xs text-slate-500 truncate">{hallazgo.territorio_nombre || 'Sin territorio'}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {hallazgo.revisado && (
                        <Badge variant="secondary" className="text-xs">Revisado</Badge>
                      )}
                      <Badge 
                        variant="outline" 
                        className={`text-xs capitalize ${
                          hallazgo.nivel_riesgo === 'alto' ? 'border-red-300 text-red-700' :
                          hallazgo.nivel_riesgo === 'medio' ? 'border-amber-300 text-amber-700' : 
                          'border-green-300 text-green-700'
                        }`}
                      >
                        {hallazgo.nivel_riesgo}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}